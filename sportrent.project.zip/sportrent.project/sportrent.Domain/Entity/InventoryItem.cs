﻿using sportrent.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sportrent.Domain.Entity
{
    public class InventoryItem
    {
        public int InventoryItemId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public InventoryStatus Status { get; set; } = InventoryStatus.Available; // Использование перечисления
    }
}
