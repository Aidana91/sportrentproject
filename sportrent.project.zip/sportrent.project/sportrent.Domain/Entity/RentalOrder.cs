﻿using sportrent.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sportrent.Domain.Entity
{
    public class RentalOrder
    {
        public int RentalOrderId { get; set; }
        public int UserId { get; set; }
        public int InventoryItemId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public RentalStatus Status { get; set; } = RentalStatus.Pending; // Использование перечисления
    }
}
