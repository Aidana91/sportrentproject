﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sportrent.Domain.Enum
{
    public enum RentalStatus
    {
        [Display(Name = "Ожидание")]
        Pending = 1,    // Ожидание
        [Display(Name = "Подтверждено")]
        Confirmed = 2,  // Подтверждено
        [Display(Name = "Завершено")]
        Completed = 3,  // Завершено
        [Display(Name = "Отменено")]
        Canceled = 4    // Отменено
    }


}
