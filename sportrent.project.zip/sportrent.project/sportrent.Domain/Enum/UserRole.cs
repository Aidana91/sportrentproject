﻿using sportrent.Domain.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sportrent.Domain.Enum
{
    public enum UserRole
    {
        [Display(Name = "Обычный пользователь")]
        User = 1,      // Обычный пользователь
        [Display(Name = "Администратор")]
        Admin = 2      // Администратор
    }
}
