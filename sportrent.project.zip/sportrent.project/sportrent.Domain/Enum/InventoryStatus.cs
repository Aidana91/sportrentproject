﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sportrent.Domain.Enum
{
    public enum InventoryStatus
    {
        [Display(Name = "Доступен")]
        Available = 1,
        [Display(Name = "Недоступен")]
        Unavailable = 2,
        [Display(Name = "Забронирован")]
        Reserved = 3,    
        [Display(Name = "На обслуживании")]
        Maintenance = 4   
    }
}
