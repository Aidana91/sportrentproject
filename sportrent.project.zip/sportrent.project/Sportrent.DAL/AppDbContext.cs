﻿using Microsoft.EntityFrameworkCore;
using sportrent.Domain.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sportrent.DAL
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

            Database.EnsureCreated();
        }

        public DbSet<User> Users { get; set; }
        public DbSet<RentalOrder> RentalOrders { get; set; }
        public DbSet<InventoryItem> InventoryItems { get; set; }
        public DbSet<Admin> Admins { get; set; }



    }
}
